#include <iostream>
#include "binary_search_tree.h"
//#include "set.h"
using namespace std;

	// Test program
int main() {
	//BinarySearchTree<int> t;

	BinarySearchTree<int> S;
	BinarySearchTree<int>::iterator itr;

	itr = S.Sinsert(4);




	

	return 0;
}
